For this lab I implemented runProgram so that we can run programs that are installed on the disk

To verify, run the compileOS.sh script.  This will rebuild the OS and install all test programs. To change which program is loaded
just change the string in the interrupt 33/4 call to be whichever program you want to run
