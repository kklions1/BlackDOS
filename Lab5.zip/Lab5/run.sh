echo "c" | bochs -f bdos.txt
